const help = (prefix) => {
	return `
「 *ᏒᎬᎶᏬᏝᏬᏕ - B⃟O⃟T⃟* 」

  *informações*
> Prefix: 「  ${prefix}  」
> Criador : K⃟1R⃟1T⃟0 & D⃟A⃟N⃟I⃟E⃟L⃟
> Se inscreve no meu canal lá fml: https://youtube.com/channel/UCz0zX7CX5V4RsFKB8lncYRQ
> Meu insta @k1r1t0_edits
> Insta do Daniel @otaku.exp
>Colaborador @foxpt_
✤  ── ♞ ──     ⃢      ── ♞ ── ✤ 
> 𝗢𝗨𝗧𝗥𝗢𝗦 𝗠𝗘𝗡𝗨𝗦 <
*╔═══✤ •ೋ°۝°ೋ•✤ ═══╗*
> menuadmin
> nsfwmenu
> paulomenu
*╚═══✤ •ೋ°۝°ೋ•✤ ═══╝*
✤  ✓ 𝗦 𝗢 𝗕 𝗥 𝗘 ✓ ✤ 
  ▋
  ▋▰   ͢   ${prefix}info
  ▋▰   ͢   ${prefix}blocklist
  ▋▰   ͢   ${prefix}chatlist
  ▋▰   ͢   ${prefix}ping
  ▋▰   ͢   ${prefix}bugreport
✤  ✓ 𝗙 𝗔 𝗭 𝗘 𝗥 ✓  ✤
  ▋
  ▋▰   ͢   ${prefix}sticker
  ▋▰   ͢   ${prefix}stickergif
  ▋▰   ͢   ${prefix}toimg
  ▋▰   ͢   ${prefix}tomp3
  ▋▰   ͢  ${prefix}bpink
  ▋▰   ͢   ${prefix}marvellogo
  ▋▰   ͢   ${prefix}snowwrite
  ▋▰   ͢   ${prefix}3dtext
  ▋▰   ͢   ${prefix}ninjalogo
  ▋▰   ͢   ${prefix}water
  ▋▰   ͢   ${prefix}firetext
  ▋▰   ͢   ${prefix}logowolf
  ▋▰   ͢   ${prefix}logowolf2
  ▋▰   ͢   ${prefix}phlogo
  ▋▰   ͢   ${prefix}glitch
  ▋▰   ͢  ${prefix}neonlogo
  ▋▰   ͢  ${prefix}neonlogo2
  ▋▰   ͢   ${prefix}lionlogo
  ▋▰   ͢   ${prefix}jokerlogo
  ▋▰   ͢   ${prefix}shadow
  ▋▰   ͢   ${prefix}burnpaper
  ▋▰   ͢   ${prefix}coffee
  ▋▰   ͢   ${prefix}lovepaper
  ▋▰   ͢   ${prefix}woodblock
  ▋▰   ͢   ${prefix}qowheart
  ▋▰   ͢   ${prefix}mutgrass
  ▋▰   ͢   ${prefix}undergocean
  ▋▰   ͢   ${prefix}woodenboards
  ▋▰   ͢   ${prefix}wolfmetal
  ▋▰   ͢   ${prefix}metalictglow
  ▋▰   ͢   ${prefix}8bit
  ▋▰   ͢   ${prefix}ttp
  ▋▰   ͢   ${prefix}herrypotter
  ▋▰   ͢   ${prefix}pubglogo
  ▋▰   ͢   ${prefix}quotemaker
✤   ✓ 𝗠 𝗜 𝗗 𝗜 𝗔  ✓  ✤ 
  ▋
  ▋▰   ͢   ${prefix}trendtwit
  ▋▰   ͢   ${prefix}randomkpop
  ▋▰   ͢   ${prefix}ytsearch
✤   ✓ 𝗘 𝗗 𝗨 𝗖 𝗔 Ç Ã 𝗢 ✓ ✤ 
  ▋
  ▋▰   ͢   ${prefix}wiki
  ▋▰   ͢   ${prefix}wikien
  ▋▰   ͢   ${prefix}nulis
  ▋▰   ͢   ${prefix}quotes
  ▋▰   ͢   ${prefix}quotes2
  ▋▰   ͢   ${prefix}artinama
✤   ✓ 𝗞𝗘𝗥𝗔𝗡𝗚 𝗔𝗝𝗔𝗜𝗕 ✓ ✤ 
  ▋
  ▋▰   ͢   ${prefix}apakah
  ▋▰   ͢   ${prefix}kapankah
  ▋▰   ͢   ${prefix}rate
  ▋▰   ͢   ${prefix}bisakah
✤   ✓  𝗕𝗔 𝗜 𝗫 𝗔 𝗥   ✓ ✤ 
  ▋▰   ͢   ${prefix}images
  ▋▰   ͢   ${prefix}ytmp3
  ▋▰   ͢   ${prefix}ytmp4
  ▋▰   ͢   ${prefix}tiktok
  ▋▰   ͢   ${prefix}joox
✤   ✓  𝗠 𝗘 𝗠 𝗘  ✓ ✤ 
  ▋
  ▋▰   ͢   ${prefix}meme
  ▋▰   ͢   ${prefix}memeindo
✤   ✓ 𝗦 𝗢 𝗠   ✓ ✤ 
  ▋
  ▋▰   ͢   ${prefix}play
  ▋▰   ͢   ${prefix}tts
✤   ✓  𝗠 𝗨 𝗦 𝗜 𝗖 𝗔   ✓ ✤ 
  ▋
  ▋▰   ͢   ${prefix}lirik
  ▋▰   ͢   ${prefix}chord
✤   ✓  𝗡Ã𝗢 𝗙𝗔𝗖𝗢 𝗜𝗗𝗘𝗔 𝗞𝗞   ✓ ✤ 
  ▋
  ▋▰   ͢   ${prefix}quran
  ✓ ✤ 𝗦 𝗧 𝗔 𝗟 𝗞 ✤   ✓  
  ▋ 
  ▋▰   ͢   ${prefix}tiktokstalk
  ▋▰   ͢   ${prefix}igstalk
✤   ✓  𝗢 𝗧 𝗔 𝗞 𝗨   ✓ ✤ 
  ▋
  ▋▰   ͢   ${prefix}neonime
  ▋▰   ͢   ${prefix}pokemon
  ▋▰   ͢   ${prefix}loli
  ▋▰   ͢   ${prefix}waifu
  ▋▰   ͢   ${prefix}randomanime
  ▋▰   ͢   ${prefix}husbu
  ▋▰   ͢   ${prefix}husbu2
  ▋▰   ͢   ${prefix}wait
  ▋▰   ͢   ${prefix}nekonime
  ✤   ✓  𝗗 𝗜 𝗩 𝗘 𝗥 𝗦 𝗔 𝗢   ✓ ✤ 
  ▋
  ▋▰   ͢   ${prefix}alay
  ▋▰   ͢   ${prefix}gantengcek
  ▋▰   ͢   ${prefix}watak
  ▋▰   ͢   ${prefix}hobby
  ▋▰   ͢   ${prefix}game
  ▋▰   ͢   ${prefix}bucin
  ▋▰   ͢   ${prefix}trust
  ▋▰   ͢   ${prefix}dare
  ▋▰   ͢   ${prefix}simi
✤   ✓  𝗜 𝗡 𝗙 𝗢   ✓ ✤ 
  ▋
  ▋▰   ͢   ${prefix}bahasa
  ▋▰   ͢   ${prefix}kodenegara
  ▋▰   ͢   ${prefix}kbbi
  ▋▰   ͢   ${prefix}fakta
  ▋▰   ͢   ${prefix}infocuaca
  ▋▰   ͢   ${prefix}infogempa
  ▋▰   ͢   ${prefix}jadwaltvnow
  ▋▰   ͢   ${prefix}covid
✤   ✓  𝗗 𝗢 𝗡 𝗢   ✓ ✤ 
  ▋
  ▋▰   ͢   ${prefix}setprefix
  ▋▰   ͢   ${prefix}block
  ▋▰   ͢   ${prefix}bc
  ▋▰   ͢   ${prefix}bcgc
  ▋▰   ͢   ${prefix}clone
  ▋▰   ͢   ${prefix}clearall
✤   ✓  𝗢 𝗨 𝗧 𝗥 𝗢 𝗦   ✓ ✤ 
  ▋
  ▋▰   ͢   ${prefix}send
  ▋▰   ͢   ${prefix}wame
  ▋▰   ͢   ${prefix}virtex
  ▋▰   ͢   ${prefix}exe
  ▋▰   ͢   ${prefix}qrcode
  ▋▰   ͢   ${prefix}afk
  ▋▰   ͢   ${prefix}timer
  ▋▰   ͢   ${prefix}fml
  ▋▰   ͢   ${prefix}fml2
✤  ── ✦ ──     ⃢      ── ✦ ── ✤ 
`
}

exports.help = help
